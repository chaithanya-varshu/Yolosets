# Stamp Detection > 2023-09-17 9:35pm
https://universe.roboflow.com/stamps-wiqjn/stamp-detection-jzg43

Provided by a Roboflow user
License: CC BY 4.0

